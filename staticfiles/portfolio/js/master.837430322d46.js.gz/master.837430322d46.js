document.querySelector('.hamburger').addEventListener('click', function () {

document.querySelector('.animated-icon1').classList.toggle('open');
});
